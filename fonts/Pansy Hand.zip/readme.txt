Pansy Hand is a pixel font made by prettypinkpansy (more of my work can be found at https://www.twitter.com/prettypinkpansy or https://beesbeesbees.itch.io/). It is effectively my pixel art handwriting. 

You can redownload this font at any time at the following link:
https://beesbeesbees.itch.io/pansy-hand

It is shared for free under the following Creative Commons license:

Attribution-ShareAlike
CC BY-SA
https://creativecommons.org/licenses/by-sa/4.0/

"You are free to:
Share - copy and redistribute the material in any medium or format
Adapt - remix, transform, and build upon the material
for any purpose, even commercially.

Under the following terms:
Attribution - You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

ShareAlike - If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

No additional restrictions - You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits."


In other words, please feel free to use this in any of your projects and modify it as-needed, just do not charge money for the font or derivative fonts. But if you make something WITH the font - e.g. you use it in a video game, you make twitch emotes with it, you use it for a cross stitch project, etc - you are free to charge money for that as long as credit is given.

I understand attribution is hard when it comes to things like twitch emotes - in this case, I would politely request that if someone asks about your emote/compliments it, occasionally mention where you got the font (preferably with a link to the itch.io page).

If you found this font useful and would like to show your appreciation, please consider donating $5 to your local animal shelter.